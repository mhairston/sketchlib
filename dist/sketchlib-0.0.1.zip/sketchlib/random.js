random.js
