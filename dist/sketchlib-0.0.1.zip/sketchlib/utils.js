/* ====================================================== *

   sketchlib - utils

   Misc. utility functions

 * ====================================================== */

/**
 * whenReady - code to run when page & resources completely loaded
 * (just some syntactic sugar for the long form)
 *
 * @param callback - function to run on DOMContentLoaded event.
 */
function whenReady(callback) {
   window.addEventListener('DOMContentLoaded', callback);
}

export {
   whenReady
};
