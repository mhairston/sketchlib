/* ====================================================== *

   sketchlib - canvas

   Canvas-related functions

 * ====================================================== */

/**
 * init - create canvas and set some defaults
 * 
 * @param {Object} options
 * @param {string} options.title - sketch title, used for document title
 *                                 and base filename for snapshots
 * @param {string} options.canvasId
 * @param {number} cw - canvas width (if undefined use window width)
 * @param {number} ch - canvas height (if undefined use window height)
 * 
 */
function init(options) {
  let ctx;
  // get canvas & set size
  const canvas = document.getElementById(options.canvasId);
  const w = options.cw || window.innerWidth;
  const h = options.ch || window.innerHeight;
  canvas.width = w;
  canvas.height = h;
  ctx = canvas.getContext('2d');

  // set defaults:
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // Side effect:
  document.title = `${options.title} - sketchlib`;

  return {
    title: options.title,
    ctx: ctx,
    canvas: canvas,
    cw: w,
    ch: h,
    hw: w * 0.5,
    hh: h * 0.5,
    pal: options.pal,
    frameRate: options.frameRate
  };
}

function background(sketch) {
  const ctx = sketch.ctx;
  ctx.save();
  ctx.strokeStyle = 'none';
  ctx.fillStyle = sketch.pal.background;
  ctx.fillRect(0, 0, sketch.cw, sketch.ch);
  ctx.restore();
}

export {
  init,
  background
};
