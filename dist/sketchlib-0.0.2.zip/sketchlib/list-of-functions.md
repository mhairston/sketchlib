
# sketchlib: List of Functions

* createSketch()
* initSketch()
* prepareSketch()
* background()
* PI
* TAU
* polar()
* drawCircle()
* palettes
* qs
* qsa
* whenReady
