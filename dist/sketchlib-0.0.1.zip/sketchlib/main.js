/* ====================================================== *

   sketchlib - main

   Drawing functions and utilities for working with 
   HTML canvas

 * ====================================================== */

//import utils from './utils.js';
import utils from './utils.js';
import geo from './geo.js';
import color from './color.js';
import init from './canvas.js';

export default {
  init,
  utils,
  geo,
  color
};
